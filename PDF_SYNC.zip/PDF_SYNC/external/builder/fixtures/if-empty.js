'use strict';
//#if
var a;
//#else
var b;
//#endif
